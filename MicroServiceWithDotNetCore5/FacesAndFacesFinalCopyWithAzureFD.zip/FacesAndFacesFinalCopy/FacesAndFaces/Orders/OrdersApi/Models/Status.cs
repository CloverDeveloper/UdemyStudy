﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrdersApi.Models
{
    public enum Status
    {
        Registered,
        Processed,
        Sent
    }
}
