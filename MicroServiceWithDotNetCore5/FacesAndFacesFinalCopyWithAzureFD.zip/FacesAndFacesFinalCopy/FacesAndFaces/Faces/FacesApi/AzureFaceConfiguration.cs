﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FacesApi
{
    public class AzureFaceConfiguration
    {
        public string AzureSubscriptionKey { get; set; }
        public string AzureEndPoint { get; set; }

    }
}
