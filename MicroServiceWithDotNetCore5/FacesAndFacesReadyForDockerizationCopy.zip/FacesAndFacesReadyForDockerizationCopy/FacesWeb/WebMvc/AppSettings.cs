﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace  WebMvc
{
    public class AppSettings
    {
        public string OrdersApiUrl { get; set; }
        public string SignalRHubUrl { get; set; }
    }
}
